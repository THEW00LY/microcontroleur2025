#include "MyTimer.h"
int n = 0;

void MyTimer_Base_Init(TIM_TypeDef *Timer, unsigned short ValARR, unsigned short ValPSC) {
	
	if (Timer == TIM1) RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	if (Timer == TIM2) RCC->APB1ENR|=	RCC_APB1ENR_TIM2EN;
	if (Timer == TIM3) RCC->APB1ENR|=	RCC_APB1ENR_TIM3EN;
	if (Timer == TIM4) RCC->APB1ENR|=	RCC_APB1ENR_TIM4EN;
	
	Timer->ARR = ValARR-1;
	Timer->PSC = ValPSC-1;
	Timer->CR1 = TIM_CR1_CEN;
}

void Init_periph(void (*ptrFonction) (void)){
	pFnc = ptrFontion;
}

void MyTimer_ActiveIT (TIM_TypeDef *Timer, int Prio, void (*IT_function) (void)){
	Timer->DIER |= TIM_DIER_UIE;
	NVIC->ISER[28] = 1;
	NVIC_EnableIRQ(28);
	NVIC_SetPriority(TIM2_IRQn, Prio);
	
}
void TIM2_IRQHandler (void) {
	TIM2->SR &=~TIM_SR_UIF;
}

