#include "stm32f10x.h"
#include "Driver_GPIO.h"
#include "MyTimer.h"

int count;

void clignote(void) {
	MyGPIO_Toggle(GPIOC, 12);
	count++;
}

int main ( void ) {
	
	MyGPIO_Init(GPIOC, 12, Out_Ppull);
	MyGPIO_Init(GPIOC, 5, Out_OD);
	
	MyTimer_Base_Init(TIM2, 1000, 36000);
	MyTimer_ActiveIT(TIM2, 0, clignote);
	MyTimer_Base_Start(TIM2);	
	
	while (1) {

	}

		
}