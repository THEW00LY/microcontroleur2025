#include "stm32f10x.h"
#include "Driver_GPIO.h"
#include "MyTimer.h"

//A FAIRE :
//mettre une bascule D (que ce soit sur A ou B) pour savoir lequel est en d�calage et donc le sens
//faire un XOR entre A et B pour r�cup�rer la valeur de l'angle (ce sera au 1/4 de degr� pr�s, r�so max)
//voir comment g�rer le reset (timer? Z?)

void IncrementalCoder(TIM_TypeDef *Timer) {
	
	Timer->CCMR1 &= ~TIM_CCMR1_CC1S;
	Timer->CCMR1 |= TIM_CCMR1_CC1S_0;
	
	Timer->CCMR2 &= ~TIM_CCMR1_CC2S;
	Timer->CCMR2 |= TIM_CCMR1_CC2S_0;
	
	Timer->CCER &= ~TIM_CCER_CC1P;
	Timer->CCER &= ~TIM_CCMR1_IC1F;
	Timer->CCER &= ~TIM_CCER_CC2P;
	Timer->CCER &= ~TIM_CCMR1_IC2F;
	
	Timer->SMCR &= ~TIM_SMCR_SMS;
	Timer->SMCR |= TIM_SMCR_SMS_0;
	Timer->SMCR |= TIM_SMCR_SMS_1;
	
	Timer->CR1 |= TIM_CR1_CEN;
	
}

int getAngle(TIM_TypeDef *Timer) {
	return (Timer->CNT)/4; //div par 4 car pr�cision au quart d'angle 
}

int treatAngle (int angle) {
	
	float angleAbsolu = (float) angle;
	if (angle > 180){
		angleAbsolu = 360.0f - angle;
	}
	
	if (angleAbsolu < 45.0f) {
		return 0;
	} else {
		return (int)(((90.0f/135.0f)* angleAbsolu) - 30.0f);
	}
	
	return -1;
}