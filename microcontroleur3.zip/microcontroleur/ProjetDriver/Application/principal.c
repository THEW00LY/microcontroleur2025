#include "stm32f10x.h"
#include "Driver_GPIO.h"

int main ( void )
{
	
		MyGPIO_Init(GPIOC, 12, Out_Ppull);
		MyGPIO_Init(GPIOC, 5, Out_OD);

	//mise du bit 6 � 1 
		MyGPIO_Set(GPIOC, 12);
	
	while (1)
	{
		if (MyGPIO_Read(GPIOC, 8) == GPIO_IDR_IDR8) {
			MyGPIO_Reset(GPIOC, 12);
		} else {
			MyGPIO_Set(GPIOC, 12);
		}
	}

}
