#ifndef MYTIMER_H
#define MYTIMER_H

#include "stm32f10x.h"



void MyTimer_Base_Init(TIM_TypeDef *Timer, unsigned short ValARR, unsigned short ValPSC);
void MyTimer_ActiveIT (TIM_TypeDef *Timer, int Prio, void (*IT_function) (void));
void MyTimer_PWM(TIM_TypeDef * Timer, int Channel);

#define MyTimer_Base_Start(Timer) Timer->CR1 |= TIM_CR1_CEN
#define MyTimer_Base_Stop(Timer) Timer->CR1 &= ~TIM_CR1_CEN

void Timer_PWM_Enable(TIM_TypeDef * timer, char channel, char mode);

void Timer_PWM_Set(TIM_TypeDef *timer, char channel, unsigned short value);

#define TIM_CHANNEL_1 1
#define TIM_CHANNEL_2 2
#define TIM_CHANNEL_3 3
#define TIM_CHANNEL_4 4

#define PWM_MODE_1 0
#define PWM_MODE_2 1

#endif