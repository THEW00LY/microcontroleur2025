#include "stm32f10x.h"
#include "UART.h"

void configureUART (USART_TypeDef *USART) {
	
}

void sendUART (USART_TypeDef *USART, char data);

int receiveUART (USART_TypeDef *USART);

