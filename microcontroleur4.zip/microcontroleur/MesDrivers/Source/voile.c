#include "voile.h"

void CommandServomoteur(TIM_TypeDef * Timer,int angle){
	
    float rapport = 7.5+(angle/36.0); //entre 5 et 10% 5 etant -90� et 10 etant 90�
		Timer_PWM_Enable(Timer, 3, 1);
		Timer_PWM_Set(Timer,3,rapport);
}

void InitSMoteur(){
    MyGPIO_Init(GPIOA, 4, Out_Ppull);
    TIM4->CR1 |= (0x1<<0);
		MyTimer_Base_Init(TIM4, 36000, 40);
    Timer_PWM_Enable(TIM4,3, 1);
  
    MyGPIO_Init(GPIOB,8,AltOut_Ppull);
}