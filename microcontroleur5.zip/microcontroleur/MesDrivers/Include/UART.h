// usart.h
#ifndef USART_H
#define USART_H

#include "stm32f10x.h"

// Mode UART
typedef enum {
    USART_MODE_T,     // Transmission seule
    USART_MODE_R,     // R�ception seule
    USART_MODE_TR     // Tx + Rx
} USART_Mode;

// Fr�quences bus (comme dans leur header)
#define PCLK1 (36U * 1000000U) // APB1 = 36 MHz
#define PCLK2 (72U * 1000000U) // APB2 = 72 MHz

void USART_Init(USART_TypeDef *USARTx, USART_Mode mode, uint32_t baudrate);

void USART_SendChar(USART_TypeDef *USARTx, char data);
int8_t USART_ReceiveChar(USART_TypeDef *USARTx);

// Petit bonus pratique
void USART_SendString(USART_TypeDef *USARTx, const char *s);

#endif