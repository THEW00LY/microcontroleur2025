#include "stm32f10x.h"

void IncrementalCoder(TIM_TypeDef *Timer);

int getAngle(TIM_TypeDef *Timer);

int treatAngle (int angle);

void extInterrupt( void (*IT_function) (void));

