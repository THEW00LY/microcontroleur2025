#ifndef VOILE_H
#define VOILE_H
//#include "stm32f10x.h"
#include "MyTimer.h"
#include "Driver_GPIO.h"

void CommandServomoteur(TIM_TypeDef * Timer,int angle);

#endif