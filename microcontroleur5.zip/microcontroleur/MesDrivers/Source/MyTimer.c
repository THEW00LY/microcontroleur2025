#include "MyTimer.h"
int n = 0;
void (*ptfnc) (void);
void MyTimer_Base_Init(TIM_TypeDef *Timer, unsigned short ValARR, unsigned short ValPSC) {
	
	if (Timer == TIM1) RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	if (Timer == TIM2) RCC->APB1ENR|=	RCC_APB1ENR_TIM2EN;
	if (Timer == TIM3) RCC->APB1ENR|=	RCC_APB1ENR_TIM3EN;
	if (Timer == TIM4) RCC->APB1ENR|=	RCC_APB1ENR_TIM4EN;
	
	Timer->ARR = ValARR-1;
	Timer->PSC = ValPSC-1;
}


void MyTimer_ActiveIT (TIM_TypeDef *Timer, int Prio, void (*IT_function) (void)){
	if (Timer == TIM2) {
		Timer->DIER |= TIM_DIER_UIE;
		NVIC_EnableIRQ(28);
		NVIC_SetPriority(TIM2_IRQn, Prio);
		ptfnc = IT_function;
	}
	
}

void Timer_PWM_Enable(TIM_TypeDef * timer, char channel, char mode) {
	if (timer == TIM1) {
		timer->BDTR |= TIM_BDTR_MOE;
	}
	if (channel == TIM_CHANNEL_1) {
		timer->CCER |= TIM_CCER_CC1E;
		timer->CCMR1 |= TIM_CCMR1_OC1M;
		if (mode == PWM_MODE_1){
			timer->CCMR1 &= ~TIM_CCMR1_OC1M_0;
		}
	}
	if (channel == TIM_CHANNEL_2) {
		timer->CCER |= TIM_CCER_CC2E;
		timer->CCMR1 |= TIM_CCMR1_OC2M;
			if (mode == PWM_MODE_1){
				timer->CCMR1 &= ~TIM_CCMR1_OC2M_0;
			}
	}
	if (channel == TIM_CHANNEL_3) {
		timer->CCER |= TIM_CCER_CC3E;
		timer->CCMR2 |= TIM_CCMR2_OC3M;
		if (mode == PWM_MODE_1){
			timer->CCMR2 &= ~TIM_CCMR2_OC3M_0;
		}
	}
	if (channel == TIM_CHANNEL_4) {
		timer->CCER |= TIM_CCER_CC4E;
		timer->CCMR2 |= TIM_CCMR2_OC4M;
		if (mode == PWM_MODE_1){
			timer->CCMR2 &= ~TIM_CCMR2_OC4M_0;
		}
	}
}

void Timer_PWM_Set(TIM_TypeDef *timer, char channel, unsigned short value) {
      if (channel == TIM_CHANNEL_1) timer->CCR1 = ((float)value/100.0)*(timer->ARR+1);
      if (channel == TIM_CHANNEL_2) timer->CCR2 = ((float)value/100.0)*(timer->ARR+1);
      if (channel == TIM_CHANNEL_3) timer->CCR3 = ((float)value/100.0)*(timer->ARR+1);
      if (channel == TIM_CHANNEL_4) timer->CCR4 = ((float)value/100.0)*(timer->ARR+1);
}


void MyTimerCodeurIncremental () {
	
}


void TIM2_IRQHandler (void) {
	TIM2->SR &=~TIM_SR_UIF;
	if (ptfnc) ptfnc();
}

