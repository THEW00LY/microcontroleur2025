// usart.c
#include "UART.h"
#include "Driver_GPIO.h"   // pour MyGPIO_Init, AltOut_Ppull, In_Floating

// � adapter en fonction de VOTRE carte �tu / c�blage !
// Je pars sur un classique :
//   - USART2: PA2 = TX, PA3 = RX
//   - USART1: PA9 = TX, PA10 = RX
//   - USART3: PB10 = TX, PB11 = RX
static void USART_ConfigGPIO(USART_TypeDef *USARTx) {
    if (USARTx == USART1) {
        RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;
        MyGPIO_Init(GPIOA, 9, AltOut_Ppull);
        MyGPIO_Init(GPIOA, 10, In_Floating);
    } else if (USARTx == USART2) {
        RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;
        MyGPIO_Init(GPIOA, 2, AltOut_Ppull);
        MyGPIO_Init(GPIOA, 3, In_Floating);
    } else if (USARTx == USART3) {
        RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
        MyGPIO_Init(GPIOB, 10, AltOut_Ppull);
        MyGPIO_Init(GPIOB, 11, In_Floating);
    }
}

void USART_Init(USART_TypeDef *USARTx, USART_Mode mode, uint32_t baudrate) {

    // 1) Horloge du p�riph�rique
    if (USARTx == USART1) {
        RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
    } else if (USARTx == USART2) {
        RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
    } else if (USARTx == USART3) {
        RCC->APB1ENR |= RCC_APB1ENR_USART3EN;
    }

    // 2) Config GPIO (TX/RX)
    USART_ConfigGPIO(USARTx);

    // 3) D�sactiver l�USART pendant la config
    USARTx->CR1 &= ~USART_CR1_UE;

    // 4) 8 bits, 1 stop, pas de parit�
    USARTx->CR1 &= ~USART_CR1_M;      // 8 bits
    USARTx->CR2 &= ~USART_CR2_STOP;   // 00 = 1 stop

    // 5) Calcul de BRR avec leurs PCLK1/PCLK2
    uint32_t pclk;
    if (USARTx == USART1) {
        pclk = PCLK2;   // USART1 sur APB2
    } else {
        pclk = PCLK1;   // USART2/3 sur APB1
    }

    float usartdiv = (float)pclk / (16.0f * (float)baudrate);
    uint32_t mantissa = (uint32_t)usartdiv;
    uint32_t frac = (uint32_t)((usartdiv - (float)mantissa) * 16.0f + 0.5f);

    USARTx->BRR = (mantissa << 4) | (frac & 0xF);

    // 6) TE/RE selon le mode
    USARTx->CR1 &= ~(USART_CR1_TE | USART_CR1_RE);
    if (mode == USART_MODE_T) {
        USARTx->CR1 |= USART_CR1_TE;
    } else if (mode == USART_MODE_R) {
        USARTx->CR1 |= USART_CR1_RE;
    } else { // TR
        USARTx->CR1 |= USART_CR1_TE | USART_CR1_RE;
    }

    // (Si tu veux les IT, tu peux ici activer RXNEIE/TCIE + NVIC)

    // 7) Activer l�USART
    USARTx->CR1 |= USART_CR1_UE;
}

void USART_SendChar(USART_TypeDef *USARTx, char data) {
    // TXE = 1 quand le DR est vide
    while (!(USARTx->SR & USART_SR_TXE)) ;
    USARTx->DR = (uint16_t)data;
}

int8_t USART_ReceiveChar(USART_TypeDef *USARTx) {
    // RXNE = 1 quand une donn�e est re�ue
    while (!(USARTx->SR & USART_SR_RXNE)) ;
    return (int8_t)(USARTx->DR & 0xFF);
}

void USART_SendString(USART_TypeDef *USARTx, const char *s) {
    while (*s) {
        USART_SendChar(USARTx, *s++);
    }
}