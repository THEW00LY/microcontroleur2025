#include "stm32f10x.h"
#include "Driver_GPIO.h"
#include "MyTimer.h"

//A FAIRE :
//mettre une bascule D (que ce soit sur A ou B) pour savoir lequel est en d�calage et donc le sens
//faire un XOR entre A et B pour r�cup�rer la valeur de l'angle (ce sera au 1/4 de degr� pr�s, r�so max)
//voir comment g�rer le reset (timer? Z?)
void (*ptfnc1)(void);

void IncrementalCoder(TIM_TypeDef *Timer) {
	
	Timer->CCMR1 &= ~TIM_CCMR1_CC1S;
	Timer->CCMR1 |= TIM_CCMR1_CC1S_0;
	
	Timer->CCMR2 &= ~TIM_CCMR1_CC2S;
	Timer->CCMR2 |= TIM_CCMR1_CC2S_0;
	
	Timer->CCER &= ~TIM_CCER_CC1P;
	Timer->CCER &= ~TIM_CCMR1_IC1F;
	Timer->CCER &= ~TIM_CCER_CC2P;
	Timer->CCER &= ~TIM_CCMR1_IC2F;
	
	Timer->SMCR &= ~TIM_SMCR_SMS;
	Timer->SMCR |= TIM_SMCR_SMS_0;
	Timer->SMCR |= TIM_SMCR_SMS_1;
	
	Timer->CR1 |= TIM_CR1_CEN;
	
}

int getAngle(TIM_TypeDef *Timer) {
	return (Timer->CNT)/4; //div par 4 car pr�cision au quart d'angle 
}

int treatAngle (int angle) {
	
	int angleAbsolu = angle;
	if (angle > 180){
		angleAbsolu = 360 - angle;
	}
	
	if (angleAbsolu < 45) {
		return 0;
	} else {
		return (((90 * angleAbsolu )/135) - 30);
	}
	
	return -1;
}

void extInterrupt( void (*IT_function) (void)) {
	NVIC_EnableIRQ(EXTI9_5_IRQn);
	NVIC_SetPriority(EXTI9_5_IRQn, 0);

	RCC->APB2ENR |= RCC_APB2ENR_AFIOEN; //on clock l'AFIO
	
	AFIO->EXTICR[1] &= ~(0xF << 4);   // clear
	AFIO->EXTICR[1] |=  EXTI_RTSR_TR1;   // PA = 0000
	
	EXTI->IMR  |= (1 << 5);   // Unmask line 5
	EXTI->RTSR |= (1 << 5);   // Rising trigger
	EXTI->FTSR &= ~(1 << 5);  // No falling trigger
	ptfnc1 = IT_function;
}


void EXTI9_5_IRQHandler(void)
{
    if (EXTI->PR & (1 << 5))   // V�rifie si c'est bien EXTI5
    {
        EXTI->PR = (1 << 5);   // Clear pending bit

        //on remet le cnt a 0
        if (ptfnc1) ptfnc1();
    }
}