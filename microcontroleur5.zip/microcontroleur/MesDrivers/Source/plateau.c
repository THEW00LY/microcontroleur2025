#include "stm32f10x.h"
#include "Driver_GPIO.h"
#include "MyTimer.h"
#include "girouette.h"
#include "voile.h"




void InitPMoteur(){
		MyTimer_Base_Init(TIM3, 3600, 1);
		Timer_PWM_Enable(TIM3, 1, 0);
		MyTimer_Base_Start(TIM3);

    MyTimer_Base_Init(TIM4, 3600, 1);
    Timer_PWM_Enable(TIM4, 1, 0);
		MyTimer_Base_Start(TIM4);

		MyGPIO_Init(GPIOA, 6, AltOut_Ppull);
		MyGPIO_Init(GPIOB, 6, AltOut_Ppull);
}

void CommandePlateau(int8_t data){

    // on re�oit un nombre entre -100 et 100


    //sens de rotation du moteur
    if( data > 0 ){ // c'est positif
            Timer_PWM_Set(TIM1, 0, 0);
        }
    else{ // c'est negatif

            Timer_PWM_Set(TIM1, 0, 100);
        }
    Timer_PWM_Set(TIM2, DATA,1);

}