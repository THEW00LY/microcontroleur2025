#include "stm32f10x.h"
#include "Driver_GPIO.h"
#include "MyTimer.h"
#include "girouette.h"
#include "voile.h"

volatile uint8_t PA0_State = 0;
int angle = 0;
int resultat = 0;

void ResetEncoder() {
	TIM2->CNT = 0;
}

int main ( void ) {
	
	
	MyGPIO_Init(GPIOA, 3, Out_Ppull); //sortie
	MyGPIO_Init(GPIOA, 0, AltOut_Ppull); // Sortie de la PWM 
	MyGPIO_Init(GPIOA, 2, In_Floating); //entr�e 1
	MyGPIO_Init(GPIOA, 3, In_Floating); //entr�e 2
	MyGPIO_Init(GPIOA, 5, In_Floating); //entr�e EXTI
	//											ARR PSC
	MyTimer_Base_Init(TIM2, 20000, 72); //nb d'impulsions = 360*4
	
	Timer_PWM_Enable(TIM2, 1, 0);
	Timer_PWM_Set(TIM2, 1, 7.0);
		
	MyTimer_Base_Start(TIM2);
	
	//extInterrupt(ResetEncoder);
	//IncrementalCoder(TIM2);
	
	//faut utiliser les interruptions externes 
	
	while (1) {
		PA0_State = (GPIOA->IDR & (1 << 0)) ? 1 : 0;
		angle = getAngle(TIM2); //on r�cup�re constamment l'angle 
		resultat = treatAngle(angle);
		CommandServomoteur(TIM2, resultat);
	}
		
}