#include "MyTimer.h"
int n = 0;
void (*ptfnc) (void);
void MyTimer_Base_Init(TIM_TypeDef *Timer, unsigned short ValARR, unsigned short ValPSC) {
	
	if (Timer == TIM1) RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	if (Timer == TIM2) RCC->APB1ENR|=	RCC_APB1ENR_TIM2EN;
	if (Timer == TIM3) RCC->APB1ENR|=	RCC_APB1ENR_TIM3EN;
	if (Timer == TIM4) RCC->APB1ENR|=	RCC_APB1ENR_TIM4EN;
	
	Timer->ARR = ValARR-1;
	Timer->PSC = ValPSC-1;
}


void MyTimer_ActiveIT (TIM_TypeDef *Timer, int Prio, void (*IT_function) (void)){
	if (Timer == TIM2) {
		Timer->DIER |= TIM_DIER_UIE;
		NVIC_EnableIRQ(28);
		NVIC_SetPriority(TIM2_IRQn, Prio);
		ptfnc = IT_function;
	}
	
}
//configurer la pwm en output pushpull alternate
//cette fontion initialise la PWM
void MyTimer_PWM(TIM_TypeDef * Timer, int Channel) {
	switch (Channel) {
		case 1:
			Timer->CCMR1 &= ~TIM_CCMR1_CC1S; //mise du bit CC1S � 00 (PWM en output)
			
			Timer->CCMR1 &= ~TIM_CCMR1_OC1M; //choix du mode de PWM
			Timer->CCMR1 |= 0x6<<4; //choix du mode de PWM
			
			Timer->CCER |= TIM_CCER_CC1E; // Capture/Compare 1 output enable
		case 2:
			Timer->CCMR1 &= ~0x300; //mise du bit CC2S � 00 (PWM en output)
		
			Timer->CCMR1 &= ~0x1000; //choix du mode de PWM
			Timer->CCMR1 |= 0x2000; //choix du mode de PWM
		
			Timer->CCER |= TIM_CCER_CC2E;
		case 3:
			Timer->CCMR2 &= ~0x3; //mise du bit CC3S � 00 (PWM en output)
		
			Timer->CCMR2 &= ~0x10; //choix du mode de PWM
			Timer->CCMR2 |= 0x60; //choix du mode de PWM
		
			Timer->CCER |= TIM_CCER_CC1E;
		case 4:
			Timer->CCMR2 &= ~0x300; //mise du bit CC4S � 00 (PWM en output)
		
			Timer->CCMR2 &= ~0x1000; //choix du mode de PWM
			Timer->CCMR2 |= 0x2000; //choix du mode de PWM
		
			Timer->CCER |= TIM_CCER_CC2E;
	}
}

void MyTimerCodeurIncremental () {
	
}


void TIM2_IRQHandler (void) {
	TIM2->SR &=~TIM_SR_UIF;
	if (ptfnc) ptfnc();
}

