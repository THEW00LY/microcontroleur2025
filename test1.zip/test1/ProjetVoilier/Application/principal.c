#include "stm32f10x.h"
#include "Driver_GPIO.h"
#include "MyTimer.h"
#include "girouette.h"

int angle = 0;
int resultat = 0;

void ResetEncoder() {
	TIM2->CNT = 0;
}

int main ( void ) {
	
	
	MyGPIO_Init(GPIOA, 3, Out_Ppull); //sortie
	MyGPIO_Init(GPIOA, 0, In_Floating); //entr�e 1
	MyGPIO_Init(GPIOA, 1, In_Floating); //entr�e 2
	MyGPIO_Init(GPIOA, 5, In_Floating); //entr�e EXTI
	
	MyTimer_Base_Init(TIM2, 1440, 1); //nb d'impulsions = 360*4
	
	extInterrupt(ResetEncoder);
	IncrementalCoder(TIM2);
	
	
	//faut utiliser les interruptions externes 
	
	while (1) {
		angle = getAngle(TIM2); //on r�cup�re constamment l'angle 
		resultat = treatAngle(angle);
	}
		
}